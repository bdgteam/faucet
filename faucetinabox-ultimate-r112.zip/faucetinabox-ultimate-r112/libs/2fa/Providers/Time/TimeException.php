<?php

use RobThree\Auth\TwoFactorAuthException;

class TimeException extends TwoFactorAuthException {}